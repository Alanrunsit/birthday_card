# birthday_card
Using the datetime and random modules to make a birthday card to determine how far your birthday is from today! 🎂
